import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [role, setRole] = useState("");
  const navigate = useNavigate();

  const handleChangeRole = (e) => {
    setRole(e.target.value);
  };

  const handleButtonClick = () => {
    sessionStorage.setItem("role", role);
    setIsLoggedIn(true);
  };

  if (isLoggedIn) {
    return <div>{navigate("/dashboard")}</div>;
  } else {
    return (
      <>
        <div className="login-background">
          <div className="login-container">
            <div className="login-firstcontainer">
              <h1>Centpays</h1>
              <div className="loginBG-img"></div>
            </div>
            <div className="login-secondcontainer">
              <div className="login-form">
                <h1>Login</h1>
                <div className="login-funtionality">
                  <input type="text" placeholder="Username" />
                  <input type="text" placeholder="Password" />
                  <select value={role} onChange={handleChangeRole}>
                    <option>Select Option</option>
                    <option value="admin">Admin</option>
                    <option value="merchant">Merchant</option>
                    <option value="employee">Employee</option>
                  </select>
                  <button className="btn" onClick={handleButtonClick}>
                    Sign In
                  </button>
                </div>
                <a href="www.google.com" className="loginbottomlink">
                  Forgotten Password?
                </a>
                <div className="line"></div>
                <div className="Logintoplink">
                  Create a new account. <span>Sign Up</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default Login;
